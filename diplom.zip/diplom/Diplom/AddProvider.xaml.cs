﻿using Diplom.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddProvider.xaml
    /// </summary>
    public partial class AddProvider : Window
    {
        public static DB.StorageK3063Entities Connection = Class.Connector.GetDatabase();
        public DB.Providers Provideris { get; set; }
        public AddProvider()
        {
            InitializeComponent();
            Provideris=new DB.Providers();
            DataContext = this;
        }

        private void AddProvi(object sender, RoutedEventArgs e)
        {
            DB.Providers providers = new DB.Providers()
            {
                ProvidersName = tbProvidersName.Text.Trim(),
                Adress = tbAdress.Text.Trim(),
            };
            Connection.Provideris.Add(providers);
            Connection.SaveChanges();
            MessageBox.Show("Данные обновлены");
            NextPage.GetProductPage().ProductList.Items.Refresh();
            this.Close();
        }
    }
}
