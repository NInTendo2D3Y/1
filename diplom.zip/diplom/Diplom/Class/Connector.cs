﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diplom.Class
{
    public static class Connector
    {
        private static DB.StorageK3063Entities DatabaseConnector;

        public static DB.StorageK3063Entities GetDatabase()
        {
            if(DatabaseConnector == null)
            {
                DatabaseConnector= new DB.StorageK3063Entities();
            }
            return DatabaseConnector;
        }
    }
}
